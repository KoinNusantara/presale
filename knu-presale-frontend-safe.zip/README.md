
# KNU Presale Frontend Safe Build

## Cara Deploy ke GitHub Pages

1. Buat repository baru di GitHub, misal: `knu-presale`
2. Upload semua file di folder `knu-presale-frontend-safe/` ke repository
3. Buka **Settings → Pages → Source → Branch main → / (root)**
4. Klik Save, GitHub akan generate link Pages
5. Buka link Pages di browser, frontend presale siap digunakan
